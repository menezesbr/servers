#!/bin/bash
exec /usr/bin/supervisord -c /etc/supervisor/supervisord.conf --nodaemon